﻿using System;
using System.Collections.Generic;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializable;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Attributes;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializer.Collections;
using DivMobi_SyncTool.SyncTool;

namespace UBT.AI4.Bio.DivMobi.DataLayer.DataItems
{
    public class IdentificationUnit : ISerializableObject
    {
        #region Instance Data

        [IDNew]
        [ColumnNew]
        private int? _CollectionSpecimenID;
        [IDNew(Autoinc = true)]
        [ColumnNew]
        private int? _IdentificationUnitID;
        [ColumnNew]
        private string _LastIdentificationCache;
        [ColumnNew]
        private string _FamilyCache;
        [ColumnNew]
        private string _OrderCache;
        [ColumnNew]
        private string _TaxonomicGroup;
        [ColumnNew]
        private bool? _OnlyObserved;
        [ColumnNew]
        private int? _RelatedUnitID;
        [ColumnNew]
        private string _RelationType;
        [ColumnNew]
        private string _ColonisedSubstratePart;
        [ColumnNew]
        private string _LifeStage;
        [ColumnNew]
        private string _Gender;
        [ColumnNew]
        private short? _NumberOfUnits;
        [ColumnNew]
        private string _ExsiccataNumber;
        [ColumnNew]
        private short? _ExsiccataIdentification;
        [ColumnNew]
        private string _UnitIdentifier;
        [ColumnNew]
        private string _UnitDescription;
        [ColumnNew]
        private string _Circumstances;
        [ColumnNew]
        private short? _DisplayOrder;
        [ColumnNew]
        private string _Notes;




        [RowGuid]
        [ColumnNew(Mapping = "rowguid")]
        private Guid _guid;

        #region Navigation

        [ManyToOneNew]
        [MappedBy("_identificationUnits")]
        private CollectionSpecimen _CollectionSpecimen;

        [ManyToOneNew]
        [MappedBy("_identificationUnits")]
        private CollTaxonomicGroup_Enum _CollTaxonomicGroup_Enum;

        [OneToManyNew]
        [JoinColums(DefColumn = "_CollectionSpecimenID", JoinColumn = "_CollectionSpecimenID")]
        [JoinColums(DefColumn = "_IdentificationUnitID", JoinColumn = "_IdentificationUnitID")]
        private IDirectAccessIterator<CollectionSpecimenImage> _CollectionSpecimenImages;

        [OneToManyNew]
        [JoinColums(DefColumn = "_CollectionSpecimenID", JoinColumn = "_CollectionSpecimenID")]
        [JoinColums(DefColumn = "_IdentificationUnitID", JoinColumn = "_IdentificationUnitID")]
        private IDirectAccessIterator<Identification> _Identifications;

        [OneToManyNew]
        [JoinColums(DefColumn = "_CollectionSpecimenID", JoinColumn = "_CollectionSpecimenID")]
        [JoinColums(DefColumn = "_IdentificationUnitID", JoinColumn = "_IdentificationUnitID")]
        private IDirectAccessIterator<IdentificationUnitAnalysis> _IdentificationUnitAnalysis;

        [OneToManyNew]
        [JoinColums(DefColumn = "_IdentificationUnitID", JoinColumn = "_RelatedUnitID")]
        private IDirectAccessIterator<IdentificationUnit> _IdentificationUnits;

        #endregion

        #endregion



        #region Default constructor

        public IdentificationUnit()
        {
            this.LastIdentificationCache    = String.Empty;
            this.OnlyObserved               = false;
            this.TaxonomicGroup             = @"unknown";
            this.DisplayOrder               = 1;
            this.NumberOfUnits              = 0;
        }

        #endregion



        #region Properties

        public int? CollectionSpecimenID { get { return _CollectionSpecimenID; } set { _CollectionSpecimenID = value; } }
        public int? IdentificationUnitID { get { return _IdentificationUnitID; } set { _IdentificationUnitID = value; } }
        public string LastIdentificationCache { get { return _LastIdentificationCache; } set { _LastIdentificationCache = value; } }
        public string FamilyCache { get { return _FamilyCache; } set { _FamilyCache = value; } }
        public string OrderCache { get { return _OrderCache; } set { _OrderCache = value; } }
        public string TaxonomicGroup { get { return _TaxonomicGroup; } set { _TaxonomicGroup = value; } }
        public bool? OnlyObserved { get { return _OnlyObserved; } set { _OnlyObserved = value; } }
        public int? RelatedUnitID { get { return _RelatedUnitID; } set { _RelatedUnitID = value; } }
        public string RelationType { get { return _RelationType; } set { _RelationType = value; } }
        public string ColonisedSubstratePart { get { return _ColonisedSubstratePart; } set { _ColonisedSubstratePart = value; } }
        public string LifeStage { get { return _LifeStage; } set { _LifeStage = value; } }
        public string Gender { get { return _Gender; } set { _Gender	 = value; } }
        public short? NumberOfUnits { get { return _NumberOfUnits; } set { _NumberOfUnits = value; } }
        public string ExsiccataNumber { get { return _ExsiccataNumber; } set { _ExsiccataNumber	 = value; } }
        public short? ExsiccataIdentification { get { return _ExsiccataIdentification	; } set { _ExsiccataIdentification = value; } }
        public string UnitIdentifier { get { return _UnitIdentifier; } set { _UnitIdentifier = value; } }
        public string UnitDescription { get { return _UnitDescription; } set { _UnitDescription = value; } }
        public string Circumstances { get { return _Circumstances; } set { _Circumstances = value; } }
        public short? DisplayOrder { get { return _DisplayOrder; } set { _DisplayOrder	= value; } }
        public string Notes { get { return _Notes; } set { _Notes = value; } }

        public CollectionSpecimen CollectionSpecimen 
        {
            get { return _CollectionSpecimen; } 
            set { _CollectionSpecimen = value; }
        }
        public CollTaxonomicGroup_Enum CollTaxonomicGroup_Enum
        {
            get { return _CollTaxonomicGroup_Enum; }
            set { _CollTaxonomicGroup_Enum = value; }
        }
        public IDirectAccessIterator<CollectionSpecimenImage> CollectionSpecimenImage
        {
            get { return _CollectionSpecimenImages; }
        }
        public IDirectAccessIterator<Identification> Identification
        {
            get { return _Identifications; }
        }
        public IDirectAccessIterator<IdentificationUnitAnalysis> IdentificationUnitAnalysis
        {
            get { return _IdentificationUnitAnalysis; }
        }
        #endregion



        #region ToString override
        public override string ToString()
        {
            return AttributeWorker.ToStringHelper(this, 30);
        }

        #endregion
    }
}
