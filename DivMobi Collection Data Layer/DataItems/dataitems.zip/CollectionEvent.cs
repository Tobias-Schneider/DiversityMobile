﻿using System;
using System.Collections.Generic;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializable;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Attributes;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializer.Collections;
using DivMobi_SyncTool.SyncTool;

namespace UBT.AI4.Bio.DivMobi.DataLayer.DataItems
{
    
    
    public class CollectionEvent : ISerializableObject
    {
        #region Instance data

        [IDNew(Autoinc=true)]
        [ColumnNew]
        private int? _CollectionEventID;
        [ColumnNew]
        private int? _Version;
        [ColumnNew]
        [UnmappedForeignKeyColumn("CollectionEventSeries", Target="server")]
        private int? _SeriesID;
        [ColumnNew]
        private string _CollectorsEventNumber;
        [ColumnNew]
        private DateTime _CollectionDate;
        [ColumnNew]
        private byte? _CollectionDay;
        [ColumnNew]
        private byte? _CollectionMonth;
        [ColumnNew]
        private short? _CollectionYear;
        [ColumnNew]
        private string _CollectionDateSupplement;
        [ColumnNew]
        private string _CollectionDateCategory;
        [ColumnNew]
        private string _CollectionTime;
        [ColumnNew]
        private string _CollectionTimeSpan;
        [ColumnNew]
        private string _LocalityDescription;
        [ColumnNew]
        private string _HabitatDescription;
        [ColumnNew]
        private string _ReferenceTitle;
        [ColumnNew]
        private string _ReferenceURI;
        [ColumnNew]
        private string _CollectingMethod;
        [ColumnNew]
        private string _Notes;
        [ColumnNew]
        private string _CountryCache;
        [ColumnNew]
        private string _DataWithholdingReason;
        [ColumnNew(Mapping = "xx_IsAvailable")]
        private bool? _IsAvailable;
        [ColumnNew(Mapping = "xx_ExpeditionID")]
        private int? _ExpeditionID;

        [RowGuid]
        [ColumnNew(Mapping = "rowguid")]
        private Guid _guid;


        [OneToManyNew(DeleteType = DeleteTypes.CASCADE)]
        [JoinColums(DefColumn = "_CollectionEventID", JoinColumn = "_CollectionEventID")]
        private IDirectAccessIterator<CollectionSpecimen> _collectionSpecimen;

        [OneToManyNew]
        [JoinColums(DefColumn = "_CollectionEventID", JoinColumn = "_CollectionEventID")]
        private IDirectAccessIterator<CollectionEventImage> _collectionEventImages;

        [OneToManyNew]
        [JoinColums(DefColumn = "_CollectionEventID", JoinColumn = "_CollectionEventID")]
        private IDirectAccessIterator<CollectionEventLocalisation> _collectionEventLocalisations;
        #endregion


        #region Default constructor

        public CollectionEvent()
        {
            this.Version = 1;
            //this.SeriesID = 0;
            this.CollectionDate = DateTime.Now;
            this._CollectionDay = (byte?)CollectionDate.Day;
            this._CollectionMonth = (byte?)CollectionDate.Month;
            this._CollectionYear = (short?)CollectionDate.Year;
            this.IsAvailable = false;
        }

        #endregion


        #region Properties

        public int? CollectionEventID { get { return _CollectionEventID; } set { _CollectionEventID = value; } }
        public int? Version { get { return _Version; } set { _Version = value; } }
        public int? SeriesID { get { return _SeriesID; } set { _SeriesID = value; } }
        public string CollectorsEventNumber { get { return _CollectorsEventNumber; } set { _CollectorsEventNumber = value; } }
        public DateTime CollectionDate { get { return _CollectionDate; } set { _CollectionDate = value; } }
        public byte? CollectionDay { get { return (byte?)_CollectionDay; } }
        public byte? CollectionMonth { get { return (byte?)_CollectionMonth; } }
        public short? CollectionYear { get { return (short?)_CollectionYear; } }
        public string CollectionDateSupplement { get { return _CollectionDateSupplement; }  set { _CollectionDateSupplement = value; } }
        public string CollectionDateCategory { get { return _CollectionDateCategory; } set { _CollectionDateCategory = value; } }
        public string CollectionTime { get { return _CollectionTime; } set { _CollectionTime = value; } }
        public string CollectionTimeSpan { get { return _CollectionTimeSpan; } set { _CollectionTimeSpan = value; } }
        public string LocalityDescription { get { return _LocalityDescription; } set { _LocalityDescription = value; } }
        public string HabitatDescription { get { return _HabitatDescription; } set { _HabitatDescription = value; } }
        public string ReferenceTitle { get { return _ReferenceTitle; } set { _ReferenceTitle = value; } }
        public string ReferenceURI { get { return _ReferenceURI; } set { _ReferenceURI = value; } }
        public string CollectingMethod { get { return _CollectingMethod; } set { _CollectingMethod = value; } }
        public string Notes { get { return _Notes; } set { _Notes = value; } }
        public string CountryCache { get { return _CountryCache; } set { _CountryCache = value; } }
        public string DataWithholdingReason { get { return _DataWithholdingReason; } set { _DataWithholdingReason = value; } }
        public bool? IsAvailable { get { return _IsAvailable; } set { _IsAvailable = value; } }
        public int? ExpeditionID { get { return _ExpeditionID; } set { _ExpeditionID = value; } }

        public IDirectAccessIterator<CollectionSpecimen> CollectionSpecimen 
        {
            get { return _collectionSpecimen; } 
        }

        public IDirectAccessIterator<CollectionEventImage> CollectionEventImage
        {
            get { return _collectionEventImages; }
        }
        public IDirectAccessIterator<CollectionEventLocalisation> CollectionEventLocalisation
        {
            get { return _collectionEventLocalisations; }
        }
        #endregion


        #region ToString override

        public override string ToString()
        {
            return AttributeWorker.ToStringHelper(this, 30);
        }

        #endregion
    }
}
 