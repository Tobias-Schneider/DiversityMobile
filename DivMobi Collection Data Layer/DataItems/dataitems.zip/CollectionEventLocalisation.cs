﻿using System;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializable;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Attributes;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializer.Collections;
using DivMobi_SyncTool.SyncTool;
using DivMobi_SyncTool.SyncTool.SyncAttributes;

namespace UBT.AI4.Bio.DivMobi.DataLayer.DataItems
{
    public class CollectionEventLocalisation : ISerializableObject
    {
        #region Instance data

        [IDNew]
        [ColumnNew]
        private int? _CollectionEventID;
        [IDNew]
        [ColumnNew]
        [DirectSyncAttribute]
        private int?   _LocalisationSystemID;
        [ColumnNew]
        private string _Location1;
        [ColumnNew]
        private string _Location2;
        [ColumnNew]
        private string _LocationAccuracy;
        [ColumnNew]
        private string _LocationNotes;
        [ColumnNew]
        private DateTime _DeterminationDate;
        [ColumnNew]
        private string _DistanceToLocation;
        [ColumnNew]
        private string _DirectionToLocation;
        [ColumnNew]
        private string _ResponsibleName;
        [ColumnNew]
        private string _ResponsibleAgentURI;
        [ColumnNew]
        private float? _AverageAltitudeCache;
        [ColumnNew]
        private float? _AverageLatitudeCache;
        [ColumnNew]
        private float?      _AverageLongitudeCache;

        [RowGuid]
        [ColumnNew(Mapping = "rowguid")]
        private Guid _guid;

        [ManyToOneNew]
        [MappedBy("_collectionEventLocalisations")]
        private CollectionEvent _CollectionEvent;

        [ManyToOneNew]
        [MappedBy("_CollectionEventLocalisations")]
        private LocalisationSystem _LocalisationSystem;

        #endregion



        #region Default constructor

        public CollectionEventLocalisation()
        {
            this.DeterminationDate = DateTime.Now;
        }

        #endregion



        #region Properties

        public int? CollectionEventID { get { return _CollectionEventID; } set { _CollectionEventID = value; } }
        public int? LocalisationSystemID { get { return _LocalisationSystemID; } set { _LocalisationSystemID = value; } }
        public string Location1 { get { return _Location1; } set { _Location1 = value; } }
        public string Location2 { get { return _Location2; } set { _Location2 = value; } }
        public string LocationAccuracy { get { return _LocationAccuracy; } set { _LocationAccuracy = value; } }
        public string LocationNotes { get { return _LocationNotes; } set { _LocationNotes = value; } }
        public DateTime DeterminationDate { get { return _DeterminationDate; } set {
            _DeterminationDate = value; 
        } }
        public string DistanceToLocation { get { return _DistanceToLocation; } set { _DistanceToLocation = value; } }
        public string DirectionToLocation { get { return _DirectionToLocation; } set { _DirectionToLocation = value; } }
        public string ResponsibleName { get { return _ResponsibleName; } set { _ResponsibleName = value; } }
        public string ResponsibleAgentURI { get { return _ResponsibleAgentURI; } set { _ResponsibleAgentURI = value; } }
        public float? AverageAltitudeCache { get { return _AverageAltitudeCache; } set { _AverageAltitudeCache = value; } }
        public float? AverageLatitudeCache { get { return _AverageLatitudeCache; } set { _AverageLatitudeCache = value; } }
        public float? AverageLongitudeCache { get { return _AverageLongitudeCache; } set { _AverageLongitudeCache = value; } }

        public CollectionEvent CollectionEvent
        {
            get{return _CollectionEvent;}
            set{_CollectionEvent=value;}
        }
        public LocalisationSystem LocalisationSystem
        {
            get { return _LocalisationSystem; }
            set { _LocalisationSystem = value; }
        }
        #endregion


        #region ToString override

        public override string ToString()
        {
            return AttributeWorker.ToStringHelper(this, 30);
        }

        #endregion
    }
}
