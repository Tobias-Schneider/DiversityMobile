﻿using System;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializable;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Attributes;
using System.Collections.Generic;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializer.Collections;
using DivMobi_SyncTool.SyncTool;

namespace UBT.AI4.Bio.DivMobi.DataLayer.DataItems
{

    public class CollectionAgent : ISerializableObject
    {
        #region Instance data

        [IDNew]
        [ColumnNew]
        private int?        _CollectionSpecimenID;
        [IDNew]
        [ColumnNew]
        private string      _CollectorsName;
        [ColumnNew]
        private string      _CollectorsAgentURI;
        [ColumnNew]
        private DateTime    _CollectorsSequence;
        [ColumnNew]
        private string      _CollectorsNumber;
        [ColumnNew]
        private string      _Notes;
        [ColumnNew]
        private string      _DataWithholdingReason;
        [ColumnNew(Mapping="xx_IsAvailable")]
        private bool?       _IsAvailable;

        [RowGuid]
        [ColumnNew(Mapping = "rowguid")]
        private Guid _guid;


        [ManyToOneNew]
        [MappedBy("_collectionAgents")]
        private CollectionSpecimen _collectionSpecimen;

        #endregion


        #region Default constructor

        public CollectionAgent() 
        {
            this.CollectorsSequence = DateTime.Now;
            this.IsAvailable = false;
        }

        #endregion



        #region Properties

        public int? CollectionSpecimenID { get { return _CollectionSpecimenID; } set { _CollectionSpecimenID = value; } }
        public string CollectorsName { get { return _CollectorsName; } set { _CollectorsName = value; } }
        public string CollectorsAgentURI { get { return _CollectorsAgentURI; } set { _CollectorsAgentURI = value; } }
        public DateTime CollectorsSequence { get { return _CollectorsSequence; } set { _CollectorsSequence = value; } }
        public string CollectorsNumber { get { return _CollectorsNumber; } set { _CollectorsNumber = value; } }
        public string Notes { get { return _Notes; } set { _Notes = value; } }
        public string DataWithholdingReason { get { return _DataWithholdingReason; } set { _DataWithholdingReason = value; } }
        public bool? IsAvailable { get { return _IsAvailable; } set { _IsAvailable = value; } }

        public CollectionSpecimen CollectionSpecimen
        {
            get { return _collectionSpecimen; }
            set { _collectionSpecimen = value; }
        }
        #endregion



        #region ToString override

        public override string ToString()
        {
            return AttributeWorker.ToStringHelper(this, 30);
        }

        #endregion
    }
}
