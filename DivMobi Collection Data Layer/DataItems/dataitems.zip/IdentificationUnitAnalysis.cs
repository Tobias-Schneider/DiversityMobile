﻿using System;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializable;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Attributes;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializer.Collections;
using DivMobi_SyncTool.SyncTool;
using DivMobi_SyncTool.SyncTool.SyncAttributes;


namespace UBT.AI4.Bio.DivMobi.DataLayer.DataItems
{
    public class IdentificationUnitAnalysis : ISerializableObject
    {
        #region Instance data
        [IDNew]
        [ColumnNew]
        private int? _CollectionSpecimenID;
        [IDNew]
        [ColumnNew]
        private int? _IdentificationUnitID;
        [IDNew]
        [ColumnNew]
        [DirectSync]
        private int? _AnalysisID;
        [IDNew]
        [ColumnNew]
        private string  _AnalysisNumber;
        [ColumnNew]
        private string _AnalysisResult;
        [ColumnNew]
        private string _ExternalAnalysisURI;
        [ColumnNew]
        private string _ResponsibleName;
        [ColumnNew]
        private string _ResponsibleAgentURI;
        [ColumnNew]
        private string  _Notes;



        [RowGuid]
        [ColumnNew(Mapping = "rowguid")]
        private Guid _guid;


        [ManyToOneNew]
        [MappedBy("_IdentificationUnitAnalysis")]
        private Analysis _Analysis;

        [ManyToOneNew]
        [MappedBy("_IdentificationUnitAnalysis")]
        private IdentificationUnit _IdentificationUnit;


        #endregion



        #region Default constructor

        public IdentificationUnitAnalysis()
        {
            
        }

        #endregion



        #region Properties

        public int? CollectionSpecimenID { get { return _CollectionSpecimenID; } set { _CollectionSpecimenID = value; } }
        public int? IdentificationUnitID { get { return _IdentificationUnitID; } set { _IdentificationUnitID = value; } }
        public int? AnalysisID { get { return _AnalysisID; } set { _AnalysisID = value; } }
        public string AnalysisNumber { get { return _AnalysisNumber; } set { _AnalysisNumber = value; } }
        public string AnalysisResult { get { return _AnalysisResult; } set { _AnalysisResult = value; } }
        public string ExternalAnalysisURI { get { return _ExternalAnalysisURI; } set { _ExternalAnalysisURI = value; } }
        public string ResponsibleName { get { return _ResponsibleName; } set { _ResponsibleName = value; } }
        public string ResponsibleAgentURI { get { return _ResponsibleAgentURI; } set { _ResponsibleAgentURI = value; } }
        public string Notes { get { return _Notes; } set { _Notes = value; } }

        public Analysis Analysis
        {
            get { return _Analysis; }
            set { _Analysis = value; }
        }
        public IdentificationUnit IdentificationUnit
        {
            get { return _IdentificationUnit; }
            set { _IdentificationUnit = value; }
        }

        #endregion



        #region ToString override

        public override string ToString()
        {
            return AttributeWorker.ToStringHelper(this, 30);
        }

        #endregion
    }
}
