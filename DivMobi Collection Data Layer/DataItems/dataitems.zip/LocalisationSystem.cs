﻿using System;
using System.Collections.Generic;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializable;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Attributes;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializer.Collections;
using DivMobi_SyncTool.SyncTool;

namespace UBT.AI4.Bio.DivMobi.DataLayer.DataItems
{
    public class LocalisationSystem : ISerializableObject
    {
        #region Instance Data
        [IDNew]
        [ColumnNew]
        private int? _LocalisationSystemID;
        [ColumnNew]
        private int? _LocalisationSystemParentID;
        [ColumnNew]
        private string _LocalisationSystemName;
        [ColumnNew]
        private string _DefaultAccuracyOfLocalisation;
        [ColumnNew]
        private string _DefaultMeasurementUnit;
        [ColumnNew]
        private string _ParsingMethodName;
        [ColumnNew]
        private string _DisplayText;
        [ColumnNew]
        private bool? _DisplayEnable;
        [ColumnNew]
        private short? _DisplayOrder;
        [ColumnNew]
        private string _Description;
        [ColumnNew]
        private string _DisplayTextLocation1;
        [ColumnNew]
        private string _DescriptionLocation1;
        [ColumnNew]
        private string _DisplayTextLocation2;
        [ColumnNew]
        private string _DescriptionLocation2;

        //[ColumnNew(Mapping = "xx_DiversityModule")]
        //private string _DiversityModule;
        //[ColumnNew(Mapping = "xx_ParsingMethod")]
        //private string _ParsingMethod;
        //[ColumnNew(Mapping = "xx_MeasurementUnit")]
        //private string _MeasurementUnit;

        [ColumnNew(Mapping="DefaultMeasurementUnit", Target="server")]
        [ColumnNew(Mapping = "xx_DefaultMeasurementUnit1")]
        private string  _DefaultMeasurementUnit1;


        [RowGuid]
        [ColumnNew(Mapping = "rowguid")]
        private Guid _guid;

        [OneToManyNew]
        [JoinColums(DefColumn = "_LocalisationSystemID", JoinColumn = "_LocalisationSystemID")]
        private IDirectAccessIterator<CollectionEventLocalisation> _CollectionEventLocalisations;

        [OneToManyNew]
        [JoinColums(DefColumn = "_LocalisationSystemID", JoinColumn = "_LocalisationSystemParentID")]
        private IDirectAccessIterator<LocalisationSystem> _LocalisationSystemChildren;

        [ManyToOneNew]
        [MappedBy("_LocalisationSystemChildren")]
        private LocalisationSystem _LocalisationSystemParent;

        #endregion



        #region Default constructor

        public LocalisationSystem()
        {
            this.LocalisationSystemName = @"unknown";
        }

        #endregion



        #region Properties

        public int? LocalisationSystemID { get { return _LocalisationSystemID; } set { _LocalisationSystemID = value; } }
        public int? LocalisationSystemParentID { get { return _LocalisationSystemParentID; } set { _LocalisationSystemParentID = value; } }
        public string LocalisationSystemName { get { return _LocalisationSystemName; } set { _LocalisationSystemName = value; } }
        public string DefaultAccuracyOfLocalisation { get { return _DefaultAccuracyOfLocalisation; } set { _DefaultAccuracyOfLocalisation = value; } }
        public string DefaultMeasurementUnit { get { return _DefaultMeasurementUnit; } set { _DefaultMeasurementUnit = value; } }
        public string ParsingMethodName { get { return _ParsingMethodName; } set { _ParsingMethodName = value; } }
        public string DisplayText { get { return _DisplayText; } set { _DisplayText = value; } }
        public bool? DisplayEnable { get { return _DisplayEnable; } set { _DisplayEnable = value; } }
        public short? DisplayOrder { get { return _DisplayOrder; } set { _DisplayOrder = value; } }
        public string Description { get { return _Description; } set { _Description = value; } }
        public string DisplayTextLocation1 { get { return _DisplayTextLocation1; } set { _DisplayTextLocation1 = value; } }
        public string DescriptionLocation1 { get { return _DescriptionLocation1; } set { _DescriptionLocation1 = value; } }
        public string DisplayTextLocation2 { get { return _DisplayTextLocation2; } set { _DisplayTextLocation2 = value; } }
        public string DescriptionLocation2 { get { return _DescriptionLocation2; } set { _DescriptionLocation2 = value; } }
        //public string DiversityModule { get { return _DiversityModule; } set { _DiversityModule = value; } }
        //public string ParsingMethod { get { return _ParsingMethod; } set { _ParsingMethod = value; } }
        //public string MeasurementUnit { get { return _MeasurementUnit; } set { _MeasurementUnit = value; } }
        public string DefaultMeasurementUnit1 { get { return _DefaultMeasurementUnit1; } set { _DefaultMeasurementUnit1 = value; } }

        public IDirectAccessIterator<CollectionEventLocalisation> CollectionEventLocalisation
        {
            get { return _CollectionEventLocalisations; }
        }
        public IDirectAccessIterator<LocalisationSystem> LocalisationSystemChildren
        {
            get { return _LocalisationSystemChildren; }
        }
        public LocalisationSystem LocalisationSystemParent
        {
            get { return _LocalisationSystemParent; }
            set { _LocalisationSystemParent = value; }
        }

        #endregion
        #region ToString override

        public override string ToString()
        {
            return AttributeWorker.ToStringHelper(this, 30);
        }

        #endregion
    }
}
