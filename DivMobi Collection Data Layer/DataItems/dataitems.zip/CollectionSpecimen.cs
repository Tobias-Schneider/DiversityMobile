﻿using System;
using System.Collections.Generic;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializable;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Attributes;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializer.Collections;
using DivMobi_SyncTool.SyncTool;

namespace UBT.AI4.Bio.DivMobi.DataLayer.DataItems
{
    
    public class CollectionSpecimen : ISerializableObject
    {
        #region Instance data

        [IDNew(Autoinc = true)]
        [ColumnNew]
        private int?        _CollectionSpecimenID;
        [ColumnNew]
        private int?        _Version;
        [ColumnNew]
        private int?        _CollectionEventID;
        [ColumnNew]
        private int?        _CollectionID;
        [ColumnNew]
        private string      _AccessionNumber;
        [ColumnNew]
        private DateTime?    _AccessionDate;
        [ColumnNew]
        private string      _AccessionDateSupplement;
        [ColumnNew]
        private string      _AccessionDateCategory;
        [ColumnNew]
        private string      _DepositorsName;
        [ColumnNew]
        private string      _DepositorsAgentURI;
        [ColumnNew]
        private string      _DepositorsAccessionNumber;
        [ColumnNew]
        private string      _LabelTitle;
        [ColumnNew]
        private string      _LabelType;
        [ColumnNew]
        private string      _LabelTranscriptionState;
        [ColumnNew]
        private string      _LabelTranscriptionNotes;
        [ColumnNew]
        private string      _ExsiccataURI;
        [ColumnNew]
        private string      _ExsiccataAbbreviation;
        [ColumnNew]
        private string      _OriginalNotes;
        [ColumnNew]
        private string      _AdditionalNotes;
        [ColumnNew]
        private string      _ReferenceTitle;
        [ColumnNew]
        private string      _ReferenceURI;
        [ColumnNew]
        private string      _Problems;
        [ColumnNew]
        private string      _DataWithholdingReason;
        [ColumnNew(Mapping = "xx_IsAvailable")]
        private bool?       _IsAvailable;

        [RowGuid]
        [ColumnNew(Mapping = "rowguid")]
        private Guid _guid;

        [ManyToOneNew]
        [MappedBy("_collectionSpecimen")]
        private CollectionEvent _collectionEvent;

        [OneToManyNew]
        [JoinColums(DefColumn = "_CollectionSpecimenID", JoinColumn = "_CollectionSpecimenID")]
        private IDirectAccessIterator<CollectionAgent> _collectionAgents;

        [OneToManyNew]
        [JoinColums(DefColumn = "_CollectionSpecimenID", JoinColumn = "_CollectionSpecimenID")]
        private IDirectAccessIterator<IdentificationUnit> _identificationUnits;

        [OneToManyNew]
        [JoinColums(DefColumn = "_CollectionSpecimenID", JoinColumn = "_CollectionSpecimenID")]
        private IDirectAccessIterator<CollectionSpecimenImage> _collectionSpecimenImages;

        #endregion


        #region Default constructor

        public CollectionSpecimen() 
        {
            this.Version        = 0;
            this.AccessionDate  = DateTime.Now;
            this.IsAvailable = false; //in der datenbank eigentlich in diesem fall nullable (db fehler?)
        }

        #endregion


        #region Properties

        public int? CollectionSpecimenID { get { return _CollectionSpecimenID; } set { this._CollectionSpecimenID = value; } }
        public int? Version { get { return _Version; } set { _Version = value; } }
        public int? CollectionEventID { get { return _CollectionEventID; } set { _CollectionEventID = value; } }
        public int? CollectionID { get { return _CollectionID; } set { _CollectionID = value; } }
        public string AccessionNumber { get { return _AccessionNumber; } set { _AccessionNumber = value; } }
        public DateTime? AccessionDate { get { return _AccessionDate; } set { _AccessionDate = value; } }
        public byte? AccessionDay 
        { 
            get 
            {
                if (_AccessionDate.HasValue)
                {
                    return (byte?)_AccessionDate.Value.Day;
                }
                else
                {
                    return null;
                }
            } 
            set 
            {
                throw new InvalidOperationException();
            } 
        }
        public byte? AccessionMonth 
        { 
            get 
            {
                if (_AccessionDate.HasValue)
                {
                    return (byte?)_AccessionDate.Value.Month;
                }
                else
                {
                    return null;
                }
            } 
            set
            {
                throw new InvalidOperationException();
            } 
        }
        public short? AccessionYear 
        { 
            get 
            {
                if (_AccessionDate.HasValue)
                {
                    return (short?)_AccessionDate.Value.Year;
                }
                else
                {
                    return null;
                }
            } 
            set 
            {
                throw new InvalidOperationException();
            } 
        }
        public string AccessionDateSupplement { get { return _AccessionDateSupplement; } set { _AccessionDateSupplement = value; } }
        public string AccessionDateCategory { get { return _AccessionDateCategory; } set { _AccessionDateCategory = value; } }
        public string DepositorsName { get { return _DepositorsName; } set { _DepositorsName = value; } }
        public string DepositorsAgentURI { get { return _DepositorsAgentURI; } set { _DepositorsAgentURI = value; } }
        public string DepositorsAccessionNumber { get { return _DepositorsAccessionNumber; } set { _DepositorsAccessionNumber = value; } }
        public string LabelTitle { get { return _LabelTitle; } set { _LabelTitle = value; } }
        public string LabelType { get { return _LabelType; } set { _LabelType = value; } }
        public string LabelTranscriptionState { get { return _LabelTranscriptionState; } set { _LabelTranscriptionState = value; } }
        public string LabelTranscriptionNotes { get { return _LabelTranscriptionNotes; } set { _LabelTranscriptionNotes = value; } }
        public string ExsiccataURI { get { return _ExsiccataURI; } set { _ExsiccataURI = value; } }
        public string ExsiccataAbbreviation { get { return _ExsiccataAbbreviation; } set { _ExsiccataAbbreviation = value; } }
        public string OriginalNotes { get { return _OriginalNotes; } set { _OriginalNotes = value; } }
        public string AdditionalNotes { get { return _AdditionalNotes; } set { _AdditionalNotes = value; } }
        public string ReferenceTitle { get { return _ReferenceTitle; } set { _ReferenceTitle = value; } }
        public string ReferenceURI { get { return _ReferenceURI; } set { _ReferenceURI = value; } }
        public string Problems { get { return _Problems; } set { _Problems = value; } }
        public string DataWithholdingReason { get { return _DataWithholdingReason; } set { _DataWithholdingReason = value; } }
        public bool? IsAvailable { get { return _IsAvailable; } set { _IsAvailable = value; } }

        public CollectionEvent CollectionEvent { get { return _collectionEvent; } set { _collectionEvent = value; } }
        public IDirectAccessIterator<CollectionAgent> CollectionAgent
        {
            get { return _collectionAgents; }
            set { _collectionAgents = value; }
        }
        public IDirectAccessIterator<IdentificationUnit> IdentificationUnit
        {
            get { return _identificationUnits; }
            set { _identificationUnits = value; }
        }
        public IDirectAccessIterator<CollectionSpecimenImage> CollectionSpecimenImage
        {
            get { return _collectionSpecimenImages; }
            set { _collectionSpecimenImages = value; }
        }
        #endregion


        #region ToString override

        public override string ToString()
        {
            return AttributeWorker.ToStringHelper(this, 30);
        }

        #endregion
    }
}
