﻿using System;
using System.Collections.Generic;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializable;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Attributes;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializer.Collections;

namespace UBT.AI4.Bio.DivMobi.DataLayer.DataItems
{
    public class CollSpecimenImageType_Enum : ISerializableObject
    {
        #region Instance Data
        [IDNew]
        [ColumnNew]
        private string _Code;
        [ColumnNew]
        private string _Description;
        [ColumnNew]
        private string _DisplayText;
        [ColumnNew]
        private short? _DisplayOrder;
        [ColumnNew]
        private bool? _DisplayEnable;
        [ColumnNew]
        private string _InternalNotes;
        [ColumnNew]
        private string  _ParentCode;

        [RowGuid]
        [ColumnNew(Mapping = "rowguid")]
        private Guid _guid;

        [OneToManyNew]
        [JoinColums(DefColumn = "_Code", JoinColumn = "_ImageType")]
        private IDirectAccessIterator<CollectionSpecimenImage> _CollectionSpecimenImages;

        #endregion



        #region Default constructor

        public CollSpecimenImageType_Enum()
        {

        }

        #endregion



        #region Properties

        public string Code { get { return _Code; } set { _Code = value; } }
        public string Description { get { return _Description; } set { _Description = value; } }
        public string DisplayText { get { return _DisplayText; } set { _DisplayText = value; } }
        public short? DisplayOrder { get { return _DisplayOrder; } set { _DisplayOrder = value; } }
        public bool? DisplayEnable { get { return _DisplayEnable; } set { _DisplayEnable = value; } }
        public string InternalNotes { get { return _InternalNotes; } set { _InternalNotes = value; } }
        public string ParentCode { get { return _ParentCode; } set { _ParentCode = value; } }

        public IDirectAccessIterator<CollectionSpecimenImage> CollectionSpecimenImage
        {
            get { return _CollectionSpecimenImages; }
        }
        #endregion



        #region ToString override

        public override string ToString()
        {
            return AttributeWorker.ToStringHelper(this, 30);
        }

        #endregion
    }
}
