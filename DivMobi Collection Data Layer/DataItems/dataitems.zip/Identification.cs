﻿using System;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializable;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Attributes;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializer.Collections;


namespace UBT.AI4.Bio.DivMobi.DataLayer.DataItems
{
    public class Identification : ISerializableObject
    {
        #region Instance Data
        [IDNew]
        [ColumnNew]
        private int? _CollectionSpecimenID;
        [IDNew]
        [ColumnNew]
        private int? _IdentificationUnitID;
        [IDNew]
        [ColumnNew]
        private short? _IdentificationSequence;
        [ColumnNew]
        private DateTime _IdentificationDate;
        [ColumnNew]
        private string _IdentificationDateSupplement;
        [ColumnNew]
        private string _IdentificationDateCategory;
        [ColumnNew]
        private string _VernacularTerm;
        [ColumnNew]
        private string _TaxonomicName;
        [ColumnNew]
        private string _NameURI;
        [ColumnNew]
        private string _IdentificationCategory;
        [ColumnNew]
        private string _IdentificationQualifier;
        [ColumnNew]
        private string _TypeStatus;
        [ColumnNew]
        private string _TypeNotes;
        [ColumnNew]
        private string _ReferenceTitle;
        [ColumnNew]
        private string _ReferenceURI;
        [ColumnNew]
        private string _Notes;
        [ColumnNew]
        private string _ResponsibleName;
        [ColumnNew]
        private string   _ResponsibleAgentURI;

        [RowGuid]
        [ColumnNew(Mapping = "rowguid")]
        private Guid _guid;

        [ManyToOneNew]
        [MappedBy("_Identifications")]
        private IdentificationUnit _IdentificationUnit;

        #endregion

        

        #region Default constructor

        public Identification()
        {
            this.IdentificationDate = DateTime.Now;
        }

        #endregion



        #region Properties

        public int? CollectionSpecimenID { get { return _CollectionSpecimenID; } set { _CollectionSpecimenID = value; } }
        public int? IdentificationUnitID { get { return _IdentificationUnitID; } set { _IdentificationUnitID = value; } }
        public short? IdentificationSequence { get { return _IdentificationSequence; } set { _IdentificationSequence = value; } }
        public DateTime IdentificationDate { get { return _IdentificationDate; } set { _IdentificationDate = value; } }
        public byte? IdentificationDay { get { return (byte?)_IdentificationDate.Day; } set { } }
        public byte? IdentificationMonth { get { return (byte?) _IdentificationDate.Month; } set { } }
        public short? IdentificationYear { get { return (short?) _IdentificationDate.Year; } set { } }
        public string IdentificationDateSupplement { get { return _IdentificationDateSupplement; } set { _IdentificationDateSupplement = value; } }
        public string IdentificationDateCategory { get { return _IdentificationDateCategory; } set { _IdentificationDateCategory = value; } }
        public string VernacularTerm { get { return _VernacularTerm; } set { _VernacularTerm = value; } }
        public string TaxonomicName { get { return _TaxonomicName; } set { _TaxonomicName = value; } }
        public string NameURI { get { return _NameURI; } set { _NameURI = value; } }
        public string IdentificationCategory { get { return _IdentificationCategory; } set { _IdentificationCategory = value; } }
        public string IdentificationQualifier { get { return _IdentificationQualifier; } set { _IdentificationQualifier = value; } }
        public string TypeStatus { get { return _TypeStatus; } set { _TypeStatus = value; } }
        public string TypeNotes { get { return _TypeNotes; } set { _TypeNotes = value; } }
        public string ReferenceTitle { get { return _ReferenceTitle; } set { _ReferenceTitle = value; } }
        public string ReferenceURI { get { return _ReferenceURI; } set { _ReferenceURI = value; } }
        public string Notes { get { return _Notes; } set { _Notes = value; } }
        public string ResponsibleName { get { return _ResponsibleName; } set { _ResponsibleName = value; } }
        public string ResponsibleAgentURI { get { return _ResponsibleAgentURI; } set { _ResponsibleAgentURI = value; } }

        public IdentificationUnit IdentificationUnit
        {
            get { return _IdentificationUnit; }
            set { _IdentificationUnit = value; }
        }
        #endregion



        #region ToString override

        public override string ToString()
        {
            return AttributeWorker.ToStringHelper(this, 30);
        }

        #endregion
   }
}
