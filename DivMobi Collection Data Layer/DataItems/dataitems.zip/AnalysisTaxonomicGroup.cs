﻿using System;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializable;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Attributes;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializer.Collections;


namespace UBT.AI4.Bio.DivMobi.DataLayer.DataItems
{
    public class AnalysisTaxonomicGroup : ISerializableObject
    {
        #region Instance Data

        [IDNew]
        [ColumnNew]
        private int?    _AnalysisID;
        [IDNew]
        [ColumnNew]
        private string  _TaxonomicGroup;

        [RowGuid]
        [ColumnNew(Mapping = "rowguid")]
        private Guid _guid;



        [ManyToOneNew]
        [MappedBy("_analysisTaxonomicGroups")]
        private Analysis _analysis;

        #endregion



        #region Default constructor

        public AnalysisTaxonomicGroup()
        {
            
        }

        #endregion



        #region Properties

        public int? AnalysisID { get { return _AnalysisID; } set { _AnalysisID = value; } }
        public string TaxonomicGroup { get { return _TaxonomicGroup; } set { _TaxonomicGroup = value; } }

        public Analysis Analysis { get { return _analysis; } set { _analysis = value; } }

        #endregion



        #region ToString override

        public override string ToString()
        {
            return AttributeWorker.ToStringHelper(this, 30);
        }

        #endregion
    }
}
