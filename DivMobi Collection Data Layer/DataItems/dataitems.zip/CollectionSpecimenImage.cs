﻿using System;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializable;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Attributes;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializer.Collections;
using DivMobi_SyncTool.SyncTool;

namespace UBT.AI4.Bio.DivMobi.DataLayer.DataItems
{
    public class CollectionSpecimenImage : ISerializableObject
    {
        #region Instance Data
        [IDNew]
        [ColumnNew]
        private int? _CollectionSpecimenID;
        [IDNew]
        [ColumnNew]
        private string _URI;
        [ColumnNew]
        private string _ResourceURI;
        [ColumnNew]
        private int? _SpecimenPartID;
        [ColumnNew]
        private int? _IdentificationUnitID;
        [ColumnNew]
        private string _ImageType;
        [ColumnNew]
        private string  _Notes;

        [RowGuid]
        [ColumnNew(Mapping = "rowguid")]
        private Guid _guid;

        [ManyToOneNew]
        [MappedBy("_collectionSpecimenImages")]
        private CollectionSpecimen _collectionSpecimen;

        [ManyToOneNew]
        [MappedBy("_CollectionSpecimenImages")]
        private CollSpecimenImageType_Enum _CollSpecimenImageType_Enum;

        [ManyToOneNew]
        [MappedBy("_CollectionSpecimenImages")]
        private IdentificationUnit _IdentificationUnitProxy;
        #endregion



        #region Default constructor

        public CollectionSpecimenImage()
        {
            
        }

        #endregion



        #region Properties

        public int? CollectionSpecimenID { get { return _CollectionSpecimenID; } set { _CollectionSpecimenID = value; } }
        public string URI { get { return _URI; } set { _URI = value; } }
        public string ResourceURI { get { return _ResourceURI; } set { _ResourceURI = value; } }
        public int? SpecimenPartID { get { return _SpecimenPartID; } set { _SpecimenPartID = value; } }
        public int? IdentificationUnitID { get { return _IdentificationUnitID; } set { _IdentificationUnitID = value; } }
        public string ImageType { get { return _ImageType; } set { _ImageType = value; } }
        public string Notes { get { return _Notes; } set { _Notes = value; } }

        public CollectionSpecimen CollectionSpecimen
        {
            get { return _collectionSpecimen; }
            set { _collectionSpecimen = value; }
        }
        public CollSpecimenImageType_Enum CollSpecimenImageType_Enum
        {
            get { return _CollSpecimenImageType_Enum; }
            set { _CollSpecimenImageType_Enum = value; }
        }
        public IdentificationUnit IdentificationUnit
        {
            get { return _IdentificationUnitProxy; }
            set { _IdentificationUnitProxy = value; }
        }
        #endregion



        #region ToString override

        public override string ToString()
        {
            return AttributeWorker.ToStringHelper(this, 30);
        }

        #endregion
    }
}
