﻿using System;
using System.Collections.Generic;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializable;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Attributes;
using UBT.AI4.Bio.DivMobi.DatabaseConnector.Serializer.Collections;
using DivMobi_SyncTool.SyncTool;

namespace UBT.AI4.Bio.DivMobi.DataLayer.DataItems
{
    public class Analysis : ISerializableObject
    {
        #region Instance Data

        [IDNew(Autoinc = true)]
        [ColumnNew]
        private int?    _AnalysisID;
        [ColumnNew]
        private int?    _AnalysisParentID;
        [ColumnNew]
        private string  _DisplayText;
        [ColumnNew]
        private string  _Description;
        [ColumnNew]
        private string  _MeasurementUnit;
        [ColumnNew]
        private string  _Notes;
        [ColumnNew]
        private string  _AnalysisURI;

        [RowGuid]
        [ColumnNew(Mapping = "rowguid")]
        private Guid _guid;

        [OneToManyNew]
        [JoinColums(DefColumn = "_AnalysisID", JoinColumn = "_AnalysisID")]
        private IDirectAccessIterator<AnalysisTaxonomicGroup> _analysisTaxonomicGroups;

        [OneToManyNew]
        [JoinColums(DefColumn = "_AnalysisID", JoinColumn = "_AnalysisID")]
        private IDirectAccessIterator<IdentificationUnitAnalysis> _IdentificationUnitAnalysis;

        [OneToManyNew]
        [JoinColums(DefColumn = "_AnalysisID", JoinColumn = "_AnalysisParentID")]
        private IDirectAccessIterator<Analysis> _Analysis;

        [ManyToOneNew]
        [MappedBy("_Analysis")]
        private Analysis _analysisParent;

        #endregion



        #region Default constructor

        public Analysis()
        {
            this.AnalysisParentID = null;
        }

        #endregion



        #region Properties

        public int? AnalysisID { get { return _AnalysisID; } set { _AnalysisID = value; } }
        public int? AnalysisParentID { get { return _AnalysisParentID; } set { _AnalysisParentID = value; } }
        public string DisplayText { get { return _DisplayText; } set { _DisplayText = value; } }
        public string Description { get { return _Description; } set { _Description = value; } }
        public string MeasurementUnit { get { return _MeasurementUnit; } set { _MeasurementUnit = value; } }
        public string Notes { get { return _Notes; } set { _Notes = value; } }
        public string AnalysisURI { get { return _AnalysisURI; } set { _AnalysisURI = value; } }

        public IDirectAccessIterator<AnalysisTaxonomicGroup> AnalysisTaxonomicGroup
        {
            get { return _analysisTaxonomicGroups; }
        }
        public IDirectAccessIterator<Analysis> AnalysisChildren
        {
            get { return _Analysis; }
        }
        public IDirectAccessIterator<IdentificationUnitAnalysis> IdentificationUnitAnalysis
        {
            get { return _IdentificationUnitAnalysis; }

        }
        public Analysis AnalysisParent 
        {
            get { return _analysisParent; }
            set { _analysisParent = value; } 
        }

        #endregion



        #region ToString override

        public override string ToString()
        {
            return AttributeWorker.ToStringHelper(this, 30);
        }

        #endregion
    }
}
